public interface GameInterface {

  void initialiseGame() throws Exception;
  void mainGame() throws Exception;
  void declareGameWinner() throws Exception;

}
